# RYN THE JOURNAL

Trading journal lokal (tanpa server/login). Data + screenshot disimpan di IndexedDB perangkat.

## Struktur
- www/index.html   -> seluruh aplikasi (HTML/CSS/JS)
- capacitor.config.json, package.json -> pembungkus Android

## Database
IndexedDB `ryn`, store `kv`: key `trades` (array trade, screenshot base64 di field `img`), key `set` (settings).
Trade: no, date, day[], pair[], session[], dir, model[], tf[], rr, risk, result, time, ideal, note, img[]

## Build APK (perlu Node.js + Android Studio)
1. npm install
2. npx cap add android
3. npx cap sync android
4. npx cap open android -> Build > Build APK(s)
5. APK: android/app/build/outputs/apk/debug/app-debug.apk

## Ganti nama app
Ubah appName di capacitor.config.json, lalu android/app/src/main/res/values/strings.xml, lalu npx cap sync.

## Ganti icon
Android Studio: klik kanan res > New > Image Asset.

## Catatan
Buka www/index.html langsung di browser untuk tes cepat. Font JetBrains Mono butuh internet; offline otomatis pakai monospace bawaan.

## Build otomatis (GitHub Actions)
Push project ke GitHub (branch main), lalu buka tab Actions > Build APK > unduh artifact `RYN-THE-JOURNAL-debug-apk`. Bisa juga dijalankan manual lewat "Run workflow".
